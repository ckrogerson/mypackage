# mypackage
This library was created as an example of how to publish one's own Python package

# How to install
...

# Troubleshooting